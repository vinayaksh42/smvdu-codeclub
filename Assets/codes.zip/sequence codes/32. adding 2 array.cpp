// 33.ADDING TWO ARRAYS!
#include <stdio.h>
int main()
{
	int i,n;
	printf("enter the number of times you want to perform addition");
	scanf("%d", &n);
	int add1[n]; //input for first number
	int add2[n]; //input for second number
	int sum[n];  //sum of both the arrays will be stored here
	
	for(i=0;i<n;i++)
	{
		printf("enter the 1st number and the 2nd number:");
		scanf("%d %d", &add1[i],&add2[i]);
		sum[i]=add1[i]+add2[i];
		printf("the sum of 2 numbers is: %d", sum[i]);
	}
	return 0;
	
}
