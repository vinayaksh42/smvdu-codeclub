#include <stdio.h>
int main()
{
	int n;
	long long result=1;
	printf("enter the number you want to find the factorial");
	scanf("%d", &n);
	int i=1;
	for(i=1;i<=n;i++)
	{
		result=result*i;
	}
	printf("%d", result);
	return 0;
}
