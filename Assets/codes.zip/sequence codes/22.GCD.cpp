#include <stdio.h>
int main()
{
	int a,b,c;
	printf("enter the first number");
	scanf("%d", &a);
	printf("enter the second number");
	scanf("%d", &b);
	while(a!=0||b!=0)
	{
		if(a==0)
		{
			c=b;
			break;
		}
		if(b==0)
		{
			c=a;
			break;
		}
		if(a>b)
		{
			a=a-b;
		}else{
			b=b-a;
		}
	}
	printf("GCD of both the number is %d", c);
	return 0;
}
