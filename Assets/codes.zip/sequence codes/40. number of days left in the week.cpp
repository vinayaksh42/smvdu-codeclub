// 41.Table of given number

#include <stdio.h>
int main()
{
	int i,a;
	printf("enter the number you want table for:");
	scanf("%d", &a);
	for(i=1;i<=10;i++)
	printf("\nTable: %d x %d = %d ", a,i,a*i);
	return 0;
}
