#include <stdio.h>
int swap(int* ptra, int* ptrb){
	int t=*ptra;
	*ptra=*ptrb;
	*ptrb=t;
	return 0;
}
int rev_array(int a[], int n){
	int* b = a+ n -1;
	while (b>a){
		swap(a,b);
		b=b-1;
		a=a+1;
	}
	return 0;
}
int main(){
	int a[10];
	int i=0;
	
	while(i<10){
		scanf("%d", &a[i]);
		i++;
	}
	rev_array(a,i);
	i=0;
	
	while(i<10){
		printf("%d", a[i]);
		i++;
	}
	return 0;
}

