#include <stdio.h>
int add(int n,int sum)
{
	if(n==0){
		return sum;
	}
	printf("enter the new number you want to add into the total sum: ");
	int a;
	scanf("%d", &a);
	sum+=a;
	n--;
	return add(n,sum);
}
int main()
{
	int sum=0,n;
	printf("enter the number of times you want to add a number to the sum: ");
	scanf("%d", &n);
	int result;
	result=add(n,sum);
	printf("the total is : %d",result);
	return 0;
}
