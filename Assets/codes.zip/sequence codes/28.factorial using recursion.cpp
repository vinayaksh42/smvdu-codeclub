#include <stdio.h>
int factorial(int n,int total)
{
	if(n==0)
	return total;
	total*=n;
	n--;
	return factorial(n,total);
}
int main()
{
	int n, total=1;
	printf("enter the number you want to find the factorial for: ");
	scanf("%d", &n);
	int result;
	result=factorial(n,total);
	printf("the factorial of %d is %d", n,result);
	return 0;
}
