#include <stdio.h>
int main()
{
	int n;
	n=25;
	int a;
	printf("enter the number\n");
	scanf("%d", &a);
	if(a<n)
	{
		printf("the number is less than 25\n");
	}else{
		printf("the number is more than 25");
	}
	return 0;
}

