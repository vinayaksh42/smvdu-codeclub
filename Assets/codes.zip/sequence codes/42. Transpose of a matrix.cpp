#include <stdio.h>
int main()
{
	int matrix[3][3];
	int i,j,temp;
	
	for(i=0;i<3;i++)
	for(j=0;j<3;j++)
	scanf("%d",&matrix[i][j]);
	
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			if(i==j)
			continue;
			
			if(i==0||i==1&&j==2)
			continue;
			
			temp=matrix[j][i];
			matrix[j][i]=matrix[i][j];
			matrix[i][j]=temp;
		}
	}
	
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			printf("%d ",matrix[i][j]);
		}
		printf("\n");
	}
	return 0;
}
