#include <stdio.h>
#define maxloan 50000
int
main ()
{
  float loan1, loan2, loan3, sum23, loan_given;
  printf ("Enter the first and second loan\n");
  scanf ("%f %f", &loan1, &loan2);
  printf ("Enter the amount of loan you want: ");
  scanf ("%f", &loan3);
  sum23 = loan2 + loan3;
  loan_given = (loan1 > 0) ? 0 : (sum23 > maxloan) ? (maxloan - loan2) : loan3;
  printf ("amount granted:%f", loan_given);
  return 0;
}
