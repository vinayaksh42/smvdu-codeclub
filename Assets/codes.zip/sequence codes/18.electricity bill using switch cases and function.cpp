#include <stdio.h>
int bill(int n)
{
    int a;
    if(n<200)
        a=1;
    if(n>200&&n<500)
        a=2;
    if(n>500)
        a=3;
    float total;
    switch (a)
    {
        case 1:
        total=n;
        break;
        case 2:
        total= 200+(n-200)*5;
        break;
        case 3:
        total= 500+(n-500)*10;
        break;
    }
    printf("your total is:%f", total);
    return 0;
}
int main()
{
    int n;
    printf("Enter your units consumed:");
    scanf("%d", &n);
    bill(n);
    return 0;
}
