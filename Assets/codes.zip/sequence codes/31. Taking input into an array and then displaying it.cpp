// 32.TAKING INPUT INTO AN ARRAY AND THEN DISPLAYING THE INPUT
#include <stdio.h>
int main()
{
	int i;
	int array[5];
	printf("enter 5 numbers!");
	for(i=0;i<5;i++)
	{
		scanf("%d", &array[i]);
	}
	for(i=0;i<5;i++)
	{
		printf("%d", array[i]);
	}
	return 0;
}
