#include <stdio.h>
int main()
{
	int array[]={1,2,3,4};
	int i=0;
	for(i=0;i<4;i++)
{
printf(�%d�, &array[i]);
}
return 0;
}
