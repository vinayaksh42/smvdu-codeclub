// 42. base sallery of a person
#include <stdio.h>
int main()
{
	float sum,bs,hra,da,medical;
	printf("enter the base salar:");
	scanf("%f",&bs);
	hra=(10/100)*bs;
	printf("hra is %f",hra);
	medical=(5/100)*bs;
	printf("medical is %f",medical);
	da=(30/100)*bs;
	printf("da is %f",da);
	sum =da+medical+hra+bs;
	printf("%f is total", sum);
	return 0;
}
