#include <stdio.h>
int main()
{
	int n,div=2;
	printf("Enter the number you want to test for PRIME NUMBER \n");
	scanf("%d", &n);
	int flag=1;
	while(div*div<=n)
	{
		if(n%div==0)
		{
			flag=0;
			printf("the number is not a prime");
			break;
		}else{
		div++;
	}
	}
	if(flag)
	{
		printf("is a prime number");
	}
	return 0;
}

