//40. Displaying the number of days left in a week
#include <stdio.h>
int main()
{
	int i,n=7;
	printf("enter the day in number format:");
	scanf("%d", &i);
	for(n=7;i<=n;i++)
	printf("%d", i);
	
	return 0;
}
