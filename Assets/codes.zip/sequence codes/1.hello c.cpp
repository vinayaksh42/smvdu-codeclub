#include <stdio.h>
int main()
{
	printf("Hello C \n"); /* this is a printf statement which will display Hello C on the output screen! */
	return 0;
}
