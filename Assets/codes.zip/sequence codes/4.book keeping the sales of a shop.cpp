#include <stdio.h>
int main()
{
	int a,b,n;
	printf("enter the number of soap \n");
	scanf("%d", &a);
	printf("enter the number of cakes \n");
	scanf("%d", &b);
	while(1)
	{
		printf("1.soap \n2.cake\n3.to end \n4.to do nothing\n");
		scanf("%d", &n);
		if(n==1)
		a=a-1;
		if(n==2)
		b=b-1;
		if(n==3)
		break;
		if(n==4)
		continue;
		printf("Number of cake: %d \n", &a);
		printf("Number of soap: %d \n", &b);
	}

	return 0;
}
