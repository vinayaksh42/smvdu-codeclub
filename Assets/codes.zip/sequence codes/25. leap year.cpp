#include <stdio.h>
int main()
{
	int n;
	printf("enter the year to check if it is leap or not \n");
	scanf("%d", &n);
	int flag=0;
	
	if(n%400==0)
	flag=1;
	else if(n%100==0)
	flag=0;
	else if(n%4==0)
	flag=1;
	
	if(flag)
	{
		printf("the year is a leap year");
	}else{
		printf("the year is not a leap year");
	}
	return 0;
}
