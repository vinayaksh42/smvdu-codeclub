#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* readline();
char** split_string(char*);

// Complete the birthdayCakeCandles function below.
int birthdayCakeCandles(int ar_count, int* ar) {
int count=0;
int i=0;
int max;
max=ar[0];
for(i=0;i<ar_count;i++){
    if(ar[i]>max){
        max=ar[i];
    }
}
for(i=0;i<ar_count;i++){
    if(ar[i]==max){
        count++;
    }
}
return count;
}

int main()
{
    int ar_count;
    printf("enter the number of candles:- ");
    scanf("%d", &ar_count);
    int ar[ar_count];
    int i=0;
    for(i=0;i<ar_count;i++){
    	
        scanf("%d", &ar[i]);
    }
    int result;
    result=birthdayCakeCandles(ar_count,ar);
    printf("the number of candles that can be blown %d", result);
    return 0;
}

