#include<stdio.h>
int main()
{
    int grades_count;
    printf("enter the number of grades you want to process:- ")
    scanf("%d", &grades_count);
    int grades[grades_count];
    int i=0;
    int helper;
    int a[grades_count];
 
    for(i=0;i<grades_count;i++){
    	printf("enter the grade:- ")
        scanf("%d", &grades[i]);
    }
    for (i=0;i<grades_count;i++)
    {
        if(grades[i]<38){
            printf("%d\n", grades[i]);
            continue;
        }
        if((grades[i]+1)%5==0){
            printf("%d\n", grades[i]+1);
            continue;
        }
        if((grades[i]+2)%5==0){
            printf("%d\n", grades[i]+2);
            continue;
        }
        printf("%d\n", grades[i]);
    }
    return 0;
}
