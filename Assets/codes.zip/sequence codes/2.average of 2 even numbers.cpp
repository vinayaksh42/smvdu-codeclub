/* 
Name :- Vinayak Sharma
SMVDU, jammu ECE
code description:- This code will take the input of 2 numbers and then calculate their average. Ultimately displaying the result!
*/
#include <stdio.h>
int main()
{
	int a, b, avg;
	
	printf("welcome to the two number average code of C \n"); /* this statement will print the initial of the program */
	
	printf("Input the 1st number and press the Enter key on your keyboard \n");
		scanf("%d", &a); /* this will take the input of first number */
	
	printf("Input the 2nd number and press the Enter key on your keyboard \n");
		scanf("%d", &b); /* this will take the input of 2nd number */
		
	if (a%2 == 0 , b%2 == 0) /* this if statement will check wether the numbers entered are even or odd, if odd then the calculation will be carried out. */
	{
		avg = (a + b)/2 ; /* mathematical operation which will conduct the average and then store it in the avg variable */
	
			printf("average of the both number is %d \n", avg);  /* final statement which will display the average of 2 numbers */
	}
	
	else 
		print("one or both of the numbers entered by the user was a odd number \n");
	
		return 0;
}
